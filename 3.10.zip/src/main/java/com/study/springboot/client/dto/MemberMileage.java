package com.study.springboot.client.dto;

public class MemberMileage {

}
