package com.study.springboot.client.dto;

import lombok.Getter;

@Getter
public class Numbering {

    int num1 = 0;
    int num2 = 1;
    int num3 = 2;
    int num4 = 3;
    int num5 = 4;
}
