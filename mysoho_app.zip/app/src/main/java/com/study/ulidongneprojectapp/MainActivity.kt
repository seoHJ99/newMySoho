package com.study.ulidongneprojectapp

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.Dialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Message
import android.provider.MediaStore
import android.util.Log
import android.view.ViewGroup
import android.webkit.*
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout


class MainActivity : AppCompatActivity(){

    lateinit var webView: WebView
    lateinit var webPopupView: WebView
    lateinit var containerView: ConstraintLayout
    private var mFilePathCallback: ValueCallback<Array<Uri?>?>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        webPopupView = findViewById(R.id.webView)
        containerView = findViewById(R.id.containerView)

        val webSettings: WebSettings = webView.settings

        webSettings.javaScriptEnabled = true
        webSettings.setJavaScriptEnabled(true); // 자바스크립트 사용 여부
        webSettings.loadWithOverviewMode = true //메타태크 허용여부
        webSettings.domStorageEnabled = true //로컬저장소 허용여부
        webSettings.allowContentAccess = true
        webSettings.allowFileAccess = true // 파일 접근 허용 설정
        webSettings.loadWithOverviewMode = true //컨텐츠가 웹뷰보다 클 때, 스크린 크기에 맞추기
        webSettings.javaScriptCanOpenWindowsAutomatically = true
        webSettings.setSupportMultipleWindows(true);   // 새창 띄우기 허용

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            webSettings.mixedContentMode  = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW //https, http 호환 여부(https에서 http컨텐츠도 보여질수 있도록 함)
        }

        /*
        webSettings.javaScriptCanOpenWindowsAutomatically = true // window.open() 동작 허용
        webSettings.loadsImagesAutomatically = true // 웹뷰에서 앱에 등록되어있는 이미지 리소스를 사용해야 할 경우 자동으로 로드 여부
        webSettings.cacheMode = WebSettings.LOAD_NO_CACHE // LOAD_NO_CACHE -> 캐시 사용 x 네트워크로만 호출, LOAD_NORMAL -> 기본적인 모드로 캐시 사용, LOAD_DEFAULT  -> 평소엔 LOAD_NORAML 캐시가 만료된 경우 네트워크를 사용, LOAD_CACHE_ONLY -> 캐시만 사용, LOAD_CACHE_ELSE_NETWORK 캐시가 없을 경우 네트워크 사용
        webSettings.userAgentString = "app"// 웹에서 해당속성을 통해 앱으로 인지 하도록
        */

        // 팝업창 띄우기
//        object : WebChromeClient() {
//            override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?): Boolean {
//
//                Log.d("Wain", "WWWWW");
//
//                val newWebView = WebView(this@MainActivity).apply {
//                    webViewClient = WebViewClient()
//                    settings.javaScriptEnabled = true
//                }
//
//                val dialog = Dialog(this@MainActivity).apply {
//                    setContentView(newWebView)
//                    window!!.attributes.width = ViewGroup.LayoutParams.MATCH_PARENT
//                    window!!.attributes.height = ViewGroup.LayoutParams.MATCH_PARENT
//                    show()
//                }
//                newWebView.webChromeClient = object : WebChromeClient() {
//                    override fun onCloseWindow(window: WebView?) {
//                        dialog.dismiss()
//                    }
//                }
//
//                (resultMsg?.obj as WebView.WebViewTransport).webView = newWebView
//                resultMsg.sendToTarget()
//                return true
//            }
//        }

        webView.webViewClient = ViewClient()
        webView.webChromeClient = ChromeClient()

        webView.loadUrl("http://3.36.210.148:8080/main")

    }

    override fun onBackPressed() {//뺵버튼 기능 누를 시 수행할 로직 구현

        Log.d("backbutton", "URL:$webPopupView")
        if (webView == webPopupView){
            Log.d("backbutton", "yes")
            if(webView.canGoBack()){// 웹사이트에서 뒤로 갈 페이지가 존재 한다면
                webView.goBack() //웹사이트 뒤로가기
            }else{
                super.onBackPressed() //본래의 빽버튼 기능 수정(안드로이드)
            }
        }else{
            Log.d("backbutton", "no")

            containerView.removeView(webPopupView)
            webPopupView.destroy()
            webPopupView = webView
        }


    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        when (requestCode) {
            2000 ->                 //fileChooser 로 파일 선택 후 onActivityResult 에서 결과를 받아 처리함
                if (resultCode == RESULT_OK) {
                    //파일 선택 완료 했을 경우
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        mFilePathCallback!!.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
                    } else {
                        mFilePathCallback!!.onReceiveValue(arrayOf(data?.data))
                    }
                    mFilePathCallback = null
                } else {
                    //cancel 했을 경우
                    if (mFilePathCallback != null) {
                        mFilePathCallback!!.onReceiveValue(null)
                        mFilePathCallback = null
                    }
                }
            else -> {}
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    private inner class ViewClient : WebViewClient() {
        //인터넷경로 URL을 시작할때 호출됨.
        override fun shouldOverrideUrlLoading(
            view: WebView,
            request: WebResourceRequest): Boolean
        {
            val url = request.url.toString()

            //리다이렉트 하고 싶으면, url을 제어해주면 됨.
            Log.d("Main", "URL:$url")

            if (url.startsWith("intent:")) {
                try {
                    val intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
                    val existPackage =
                        packageManager.getLaunchIntentForPackage(intent.getPackage()!!)
                    if (existPackage != null) {
                        startActivity(intent)
                    } else {
                        val marketIntent = Intent(Intent.ACTION_VIEW)
                        marketIntent.data = Uri.parse("market://details?id=" + intent.getPackage())
                        startActivity(marketIntent)
                    }
                    return true
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            } else {
                view.loadUrl(url)
            }

            return super.shouldOverrideUrlLoading(view, request)
        }
    }

    private inner class ChromeClient() : WebChromeClient() {

        //JS로 얼럿창을 띄울때 호출됨.
        override fun onJsAlert(
            view: WebView?,
            url: String?,
            message: String?,
            result: JsResult
        ): Boolean {
            AlertDialog.Builder(view!!.context)
                .setMessage(message)
                .setPositiveButton(
                    android.R.string.ok
                ) { dialog, which -> result.confirm() }
                .setNegativeButton(
                    android.R.string.cancel
                ) { dialog, which -> result.cancel() }
                .create()
                .show()
            return true
        }

        override fun onJsConfirm(
            view: WebView?,
            url: String?,
            message: String?,
            result: JsResult
        ): Boolean {
            AlertDialog.Builder(view!!.context)
                .setTitle("title")
                .setMessage(message)
                .setPositiveButton(
                    android.R.string.ok
                ) { dialog, which -> result.confirm() }
                .setNegativeButton(
                    android.R.string.cancel
                ) { dialog, which -> result.cancel() }
                .setCancelable(false)
                .create()
                .show()
            return true
        }

        @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
        override fun onShowFileChooser(
            webView: WebView?,
            filePathCallback: ValueCallback<Array<Uri?>?>,
            fileChooserParams: FileChooserParams?
        ): Boolean {

            if (mFilePathCallback != null) {
                mFilePathCallback!!.onReceiveValue(null)
                mFilePathCallback = null
            }
            mFilePathCallback = filePathCallback

            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            val REQUEST_CODE = 2000
            startActivityForResult(intent, REQUEST_CODE)

            return true
        }

        @SuppressLint("SetJavaScriptEnabled")
        override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?): Boolean {
                Log.d("로그 ","onCreateWindow")
                webPopupView = WebView(this@MainActivity).apply {
                    webViewClient = WebViewClient()
                    settings.javaScriptEnabled = true
                    settings.setJavaScriptEnabled(true); // 자바스크립트 사용 여부
                    settings.loadWithOverviewMode = true //메타태크 허용여부
                    settings.domStorageEnabled = true //로컬저장소 허용여부
                    settings.allowContentAccess = true
                    settings.allowFileAccess = true // 파일 접근 허용 설정
                    settings.loadWithOverviewMode = true //컨텐츠가 웹뷰보다 클 때, 스크린 크기에 맞추기
                    settings.javaScriptCanOpenWindowsAutomatically = true
                    settings.setSupportMultipleWindows(true);   // 새창 띄우기 허용
                }
                webPopupView.setLayoutParams(
                    ConstraintLayout.LayoutParams(
                        ConstraintLayout.LayoutParams.MATCH_PARENT,
                        ConstraintLayout.LayoutParams.MATCH_PARENT
                    )
                )
                containerView.addView(webPopupView)

                webPopupView.setWebChromeClient(object : WebChromeClient() {
                    override fun onCloseWindow(window: WebView) {
                        Log.d("로그 ","close")
                        containerView.removeView(window)
                        window.destroy()
                        webPopupView = webView
                    }
                })

                webPopupView.setWebViewClient(object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(
                        view: WebView,
                        request: WebResourceRequest): Boolean
                    {
                        val url = request.url.toString()

                        //리다이렉트 하고 싶으면, url을 제어해주면 됨.
                        Log.d("Main", "URL:$url")

                        if (url.startsWith("intent:")) {
                            try {
                                val intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
                                val existPackage =
                                    packageManager.getLaunchIntentForPackage(intent.getPackage()!!)
                                if (existPackage != null) {
                                    startActivity(intent)
                                } else {
                                    val marketIntent = Intent(Intent.ACTION_VIEW)
                                    marketIntent.data = Uri.parse("market://details?id=" + intent.getPackage())
                                    startActivity(marketIntent)
                                }
                                return true
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        } else {
                            view.loadUrl(url)
                        }

                        return super.shouldOverrideUrlLoading(view, request)
                    }
                })

                (resultMsg?.obj as WebView.WebViewTransport).webView = webPopupView
                resultMsg.sendToTarget()
                return true
        }
    }

//        @SuppressLint("SetJavaScriptEnabled")
//        override fun onCreateWindow(
//            view: WebView,
//            isDialog: Boolean,
//            isUserGesture: Boolean,
//            resultMsg: Message
//        ): Boolean {
//            // window.opener 시
//            Log.e("eeeee","wwwwwww");
//            webPopupView = WebView(view.context)
//            webPopupView.getSettings().setJavaScriptEnabled(true)
//            webPopupView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true)
//            webPopupView.getSettings().setSupportMultipleWindows(true)
//            webPopupView.getSettings().setDomStorageEnabled(true)
//            webPopupView.setWebChromeClient(object : WebChromeClient() {
//                override fun onCloseWindow(window: WebView) {
//                    containerView.removeView(window)
//                    window.destroy()
//                }
//            })
////            webPopupView.setWebViewClient(SslWebViewConnect())
//            webPopupView.setLayoutParams(
//                ConstraintLayout.LayoutParams(
//                    ConstraintLayout.LayoutParams.MATCH_PARENT,
//                    ConstraintLayout.LayoutParams.MATCH_PARENT
//                )
//            )
//            containerView.addView(webPopupView)
//            val transport = resultMsg.obj as WebViewTransport
//            transport.webView = webPopupView
//            resultMsg.sendToTarget()
//            return true
//        }


}