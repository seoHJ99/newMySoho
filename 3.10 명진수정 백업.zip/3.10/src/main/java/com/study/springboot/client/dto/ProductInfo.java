package com.study.springboot.client.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
//made by 형민
public class ProductInfo {

    private int item_IDX;
    private String status;
    private String item_NAME;
    private String item_IMAGE;
    private int item_PRICE;
    private int item_PRICE_DISCOUNT;
    private int item_DISCOUNT;
    private int qty;
    private int item_FULL_PRICE;
    private String item_OPTION;





}
